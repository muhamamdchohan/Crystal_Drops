import { useEffect, useRef, useState, type ChangeEvent, type CSSProperties, type FormEvent, type MouseEvent, type ReactNode, type RefObject } from 'react';
import { Route, Router, Switch, useLocation } from 'wouter';
import { ArrowRight, Droplets, Hotel, Menu, RotateCcw, Upload, Utensils, X, MessageCircle, MapPin, Sparkles } from 'lucide-react';

const WHATSAPP_NUMBER = '923212486102';
const ROUTES = ['/', '/customize', '/gallery', '/how-it-works', '/industries', '/about', '/contact', '/faq'];
const routeMeta: Record<string, { title: string; description: string }> = {
  '/': { title: 'Custom-Labelled Drinking Water in Karachi | Crystal Drops', description: 'Custom-labelled drinking water for restaurants, hotels, companies and events. Put your brand on the bottle with Crystal Drops, Karachi.' },
  '/customize': { title: 'Customize Your Bottle | Crystal Drops Karachi', description: 'Preview custom bottle labels, explore sizes and palettes, and prepare a branded bottled-water inquiry with Crystal Drops.' },
  '/gallery': { title: 'Custom Bottle Label Concepts | Crystal Drops', description: 'Explore fictional custom-labelled bottle concepts for restaurants, hotels, cafes, corporate events and celebrations.' },
  '/how-it-works': { title: 'How Custom-Labelled Water Works | Crystal Drops', description: 'Learn how to share your brand, review a custom bottle-label concept and discuss your order requirements with Crystal Drops.' },
  '/industries': { title: 'Custom-Labelled Water for Businesses & Events | Crystal Drops', description: 'Explore custom-labelled bottled water concepts for restaurants, cafes, hotels, corporate companies and events.' },
  '/about': { title: 'About Crystal Drops | Karachi Custom-Labelled Water', description: 'Meet Crystal Drops, a Karachi-based custom-labelled drinking-water business that puts your brand identity on the bottle.' },
  '/contact': { title: 'Contact & Order Inquiry | Crystal Drops Karachi', description: 'Share your bottled-water requirements and open a WhatsApp inquiry draft with Crystal Drops.' },
  '/faq': { title: 'Frequently Asked Questions | Crystal Drops', description: 'Answers about custom bottle labels, logo use, sizes, pricing, minimum quantities and delivery arrangements.' },
};

type PaletteKey = 'black' | 'blue' | 'red' | 'ivory';
type Palette = { key: PaletteKey; name: string; bg: string; text: string; accent: string; swatch: string };
const palettes: Palette[] = [
  { key: 'black', name: 'Black / gold', bg: '#071827', text: '#D6B15E', accent: '#D6B15E', swatch: 'linear-gradient(135deg,#071827 0 50%,#D6B15E 50%)' },
  { key: 'blue', name: 'Blue / white', bg: '#103D5C', text: '#FFFFFF', accent: '#EAF5FC', swatch: 'linear-gradient(135deg,#103D5C 0 50%,#fff 50%)' },
  { key: 'red', name: 'Red / white', bg: '#982F35', text: '#FFFFFF', accent: '#FFFFFF', swatch: 'linear-gradient(135deg,#982F35 0 50%,#fff 50%)' },
  { key: 'ivory', name: 'Ivory / navy', bg: '#F4EBD8', text: '#071827', accent: '#D6B15E', swatch: 'linear-gradient(135deg,#F4EBD8 0 50%,#071827 50%)' },
];
type Concept = { id: string; name: string; category: string; palette: PaletteKey; tagline: string; description: string };
const concepts: Concept[] = [
  { id: 'saffron-table', name: 'Saffron Table', category: 'Restaurant', palette: 'black', tagline: 'A considered dining detail', description: 'A fictional fine-dining concept with a dark, restrained label and a warm metallic accent. A sample direction only—not a client project.' },
  { id: 'the-meridian', name: 'The Meridian', category: 'Hotel', palette: 'blue', tagline: 'Quiet hospitality', description: 'A fictional hotel concept using deep blue and clean white space to complement a considered guest experience. Shown for inspiration only.' },
  { id: 'northline', name: 'Northline Works', category: 'Corporate', palette: 'blue', tagline: 'Made for the meeting table', description: 'A fictional corporate identity in a clear, structured palette for meetings and hosted business events.' },
  { id: 'small-hours', name: 'Small Hours', category: 'Cafe', palette: 'ivory', tagline: 'A softer kind of everyday', description: 'A fictional independent café concept, pairing warm ivory with deep navy for a relaxed but polished table setting.' },
  { id: 'sunday-letter', name: 'Sunday Letter', category: 'Events', palette: 'red', tagline: 'A personal celebration', description: 'A fictional wedding and event concept in a confident red-and-white palette. Personalization shown here is illustrative.' },
  { id: 'form-and-field', name: 'Form & Field', category: 'Restaurant', palette: 'ivory', tagline: 'Minimal by design', description: 'A fictional modern restaurant concept with quiet typography and an understated ivory label.' },
];
const categories = ['All concepts', 'Restaurant', 'Hotel', 'Corporate', 'Cafe', 'Events'];
const bottleSrc = '/crystal-bottle.png';
const paletteFor = (key: PaletteKey) => palettes.find((palette) => palette.key === key) ?? palettes[0];
const whatsappUrl = (message: string) => `https://wa.me/${WHATSAPP_NUMBER}?${new URLSearchParams({ text: message }).toString()}`;

type OrderForm = {
  businessName: string; contactName: string; phone: string; email: string; size: string; quantity: string;
  category: string; deliveryArea: string; brandName: string; labelColors: string; labelStyle: string;
  capPreference: string; instructions: string;
};
const emptyForm: OrderForm = {
  businessName: '', contactName: '', phone: '', email: '', size: '500 ml', quantity: '', category: '',
  deliveryArea: '', brandName: '', labelColors: 'Black / gold', labelStyle: '', capPreference: 'Midnight navy', instructions: '',
};
const capOptions = [
  { label: 'Midnight navy', value: '#071827' }, { label: 'Deep blue', value: '#103D5C' },
  { label: 'Champagne gold', value: '#D6B15E' }, { label: 'White', value: '#FFFFFF' },
];

function Bottle({ size, palette, name, cap, logo, className = '', loading = 'lazy', labelStyle = '' }: { size: string; palette: PaletteKey; name: string; cap: string; logo?: string | null; className?: string; loading?: 'eager' | 'lazy'; labelStyle?: string }) {
  const colors = paletteFor(palette);
  const styleClass = labelStyle ? `label-style-${labelStyle.toLowerCase().replace(/[^a-z]+/g, '-')}` : '';
  return (
    <div className={`bottle-mock ${size === '1.5 L' ? 'large' : ''} ${styleClass} ${className}`} style={{ '--cap': cap, '--label-bg': colors.bg, '--label-text': colors.text, '--label-accent': colors.accent } as CSSProperties} data-testid="preview-bottle">
      <img src={bottleSrc} alt={`${size} clear bottled-water preview with a ${colors.name} custom label`} width="420" height="900" loading={loading} decoding="async" />
      <span className="cap-overlay" aria-hidden="true" />
      <div className="live-label" aria-label={`Illustrative ${name || 'your brand'} label`}>
        {logo && <img className="label-logo" src={logo} alt="Your uploaded logo preview" />}
        <span className="label-name">{name || 'Your Brand'}</span>
        <span className="label-sub">CUSTOM LABEL CONCEPT</span><span className="label-rule" /><span className="label-size">{size}</span>
      </div>
    </div>
  );
}

function WhatsAppLink({ message, children, className, testId, label }: { message: string; children: ReactNode; className: string; testId: string; label: string }) {
  return <a href={whatsappUrl(message)} target="_blank" rel="noopener noreferrer" className={className} aria-label={label} data-testid={testId}>{children}</a>;
}

function App() {
  return <Router><CrystalSite /></Router>;
}

function CrystalSite() {
  const [location, setLocation] = useLocation();
  const path = location.replace(/\/+$/, '') || '/';
  const [navOpen, setNavOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [palette, setPalette] = useState<PaletteKey>('black');
  const [size, setSize] = useState('500 ml');
  const [brandName, setBrandName] = useState('Your Brand');
  const [cap, setCap] = useState('#071827');
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [logoName, setLogoName] = useState('');
  const [logoMessage, setLogoMessage] = useState('');
  const [form, setForm] = useState<OrderForm>(emptyForm);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [consent, setConsent] = useState(false);
  const [formStatus, setFormStatus] = useState('');
  const [reviewOpen, setReviewOpen] = useState(false);
  const [conceptFilter, setConceptFilter] = useState('All concepts');
  const [activeConcept, setActiveConcept] = useState<Concept | null>(null);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const transitionTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const focusReturnRef = useRef<HTMLElement | null>(null);
  const dialogRef = useRef<HTMLDivElement>(null);
  const reviewHeadingRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    transitionTimer.current = setTimeout(() => setLoading(false), 950);
    return () => { if (transitionTimer.current) clearTimeout(transitionTimer.current); };
  }, []);
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || !('IntersectionObserver' in window)) return;
    const nodes = document.querySelectorAll('.section-head, .industry-row, .benefit-item, .process-step, .about-art, .intro-grid, .route-reveal');
    nodes.forEach((node) => node.classList.add('scroll-reveal'));
    const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); }
    }), { threshold: 0.12 });
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, [path]);
  useEffect(() => {
    const metadata = routeMeta[path] ?? routeMeta['/'];
    document.title = metadata.title;
    const description = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    const ogTitle = document.querySelector<HTMLMetaElement>('meta[property="og:title"]');
    const ogDescription = document.querySelector<HTMLMetaElement>('meta[property="og:description"]');
    const twitterTitle = document.querySelector<HTMLMetaElement>('meta[name="twitter:title"]');
    const twitterDescription = document.querySelector<HTMLMetaElement>('meta[name="twitter:description"]');
    if (description) description.content = metadata.description;
    if (ogTitle) ogTitle.content = metadata.title;
    if (ogDescription) ogDescription.content = metadata.description;
    if (twitterTitle) twitterTitle.content = metadata.title;
    if (twitterDescription) twitterDescription.content = metadata.description;
  }, [path]);
  useEffect(() => {
    const onPopState = () => {
      if (transitionTimer.current) clearTimeout(transitionTimer.current);
      setLoading(true);
      transitionTimer.current = setTimeout(() => setLoading(false), window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 220 : 1000);
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);
  useEffect(() => {
    if (!activeConcept) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { closeConcept(); return; }
      if (event.key !== 'Tab' || !dialogRef.current) return;
      const focusable = dialogRef.current.querySelectorAll<HTMLElement>('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])');
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', onKey);
    dialogRef.current?.querySelector<HTMLElement>('button')?.focus();
    return () => document.removeEventListener('keydown', onKey);
  }, [activeConcept]);
  useEffect(() => () => { if (logoUrl) URL.revokeObjectURL(logoUrl); }, [logoUrl]);
  useEffect(() => {
    if (reviewOpen) requestAnimationFrame(() => reviewHeadingRef.current?.focus());
  }, [reviewOpen]);
  useEffect(() => {
    const closeMenu = (event: KeyboardEvent) => { if (event.key === 'Escape') setNavOpen(false); };
    document.addEventListener('keydown', closeMenu);
    return () => document.removeEventListener('keydown', closeMenu);
  }, []);

  const handleSiteClick = (event: MouseEvent<HTMLDivElement>) => {
    const target = event.target as HTMLElement;
    const anchor = target.closest('a[href]') as HTMLAnchorElement | null;
    if (!anchor || anchor.target === '_blank' || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const url = new URL(anchor.href, window.location.href);
    if (url.origin !== window.location.origin || !ROUTES.includes(url.pathname) || url.pathname === path) return;
    event.preventDefault();
    setNavOpen(false);
    if (transitionTimer.current) clearTimeout(transitionTimer.current);
    setLoading(true);
    setLocation(url.pathname);
    transitionTimer.current = setTimeout(() => setLoading(false), window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 220 : 1000);
    window.scrollTo({ top: 0, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
  };
  const closeConcept = () => {
    setActiveConcept(null);
    requestAnimationFrame(() => focusReturnRef.current?.focus());
  };
  const openConcept = (concept: Concept, event: MouseEvent<HTMLButtonElement>) => {
    focusReturnRef.current = event.currentTarget;
    setActiveConcept(concept);
  };
  const updateForm = (key: keyof OrderForm, value: string) => {
    setForm((previous) => ({ ...previous, [key]: value }));
    setFormErrors((previous) => ({ ...previous, [key]: '' }));
    setFormStatus('');
  };
  const selectPalette = (key: PaletteKey) => {
    const next = paletteFor(key);
    setPalette(key);
    updateForm('labelColors', next.name);
  };
  const selectSize = (next: string) => {
    setSize(next);
    updateForm('size', next);
  };
  const selectCap = (next: string) => {
    setCap(next);
    updateForm('capPreference', capOptions.find((option) => option.value === next)?.label ?? next);
  };
  const handleLogo = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const extension = file.name.split('.').pop()?.toLowerCase() ?? '';
    const extensionType: Record<string, string[]> = {
      png: ['image/png'], jpg: ['image/jpeg', 'image/jpg'], jpeg: ['image/jpeg', 'image/jpg'], svg: ['image/svg+xml'],
    };
    const validType = extension in extensionType && extensionType[extension].includes(file.type);
    if (!validType) {
      setLogoMessage('Choose a matching PNG, JPG, JPEG or SVG image. The logo remains on this device.');
      event.target.value = '';
      return;
    }
    if (file.size > 3 * 1024 * 1024) {
      setLogoMessage('Choose a logo smaller than 3 MB. The logo remains on this device.');
      event.target.value = '';
      return;
    }
    if (logoUrl) URL.revokeObjectURL(logoUrl);
    const safeName = file.name.replace(/[\u0000-\u001F\u007F]/g, '').trim().slice(0, 160);
    setLogoUrl(URL.createObjectURL(file));
    setLogoName(safeName);
    setLogoMessage(`${safeName} is previewed locally. WhatsApp cannot attach this file automatically; attach it manually after WhatsApp opens.`);
    event.target.value = '';
  };
  const resetDesign = () => {
    if (logoUrl) URL.revokeObjectURL(logoUrl);
    setLogoUrl(null); setLogoName(''); setLogoMessage('');
    setPalette('black'); setSize('500 ml'); setBrandName('Your Brand'); setCap('#071827');
    setForm((previous) => ({ ...previous, size: '500 ml', brandName: '', labelColors: 'Black / gold', labelStyle: '', capPreference: 'Midnight navy' }));
    setFormErrors({});
    setFormStatus('');
    setConsent(false);
    setReviewOpen(false);
  };
  const validateOrder = (includeConsent: boolean) => {
    const errors: Record<string, string> = {};
    if (!form.businessName.trim()) errors.businessName = 'Enter your business or customer name.';
    if (!form.contactName.trim()) errors.contactName = 'Enter a contact person.';
    if (!form.phone.trim() || form.phone.trim().replace(/[^\d+]/g, '').length < 7) errors.phone = 'Enter a valid phone number.';
    if (form.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) errors.email = 'Enter a valid email address or leave this blank.';
    if (!form.size) errors.size = 'Choose a bottle size.';
    if (!form.quantity.trim() || !Number.isFinite(Number(form.quantity)) || Number(form.quantity) <= 0) errors.quantity = 'Enter an estimated quantity greater than zero.';
    if (!form.category) errors.category = 'Choose a business category.';
    if (!form.deliveryArea.trim()) errors.deliveryArea = 'Enter your delivery city or area.';
    if (!form.brandName.trim()) errors.brandName = 'Enter the brand name for your label.';
    if (!form.labelColors.trim()) errors.labelColors = 'Add your preferred label colors.';
    if (!form.labelStyle) errors.labelStyle = 'Choose a label style.';
    if (!form.capPreference) errors.capPreference = 'Choose a cap preference.';
    if (includeConsent && !consent) errors.consent = 'Please agree before opening WhatsApp with your inquiry draft.';
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  const setBrand = (value: string) => {
    setBrandName(value);
    updateForm('brandName', value);
  };
  const orderMessage = () => {
    const details = [
      ['Business Name', form.businessName], ['Contact Person', form.contactName], ['Phone', form.phone], ['Email', form.email],
    ].filter(([, value]) => String(value).trim());
    const requirements = [
      ['Bottle Size', form.size], ['Estimated Quantity', form.quantity], ['Business Category', form.category], ['Delivery Area', form.deliveryArea],
    ].filter(([, value]) => String(value).trim());
    const branding = [
      ['Brand Name', form.brandName || brandName], ['Label Colors', form.labelColors], ['Label Style', form.labelStyle],
      ['Cap Preference', form.capPreference], ['Logo file', logoName], ['Additional Instructions', form.instructions],
    ].filter(([, value]) => String(value).trim());
    const lines = [
      'Hello Crystal Drops!', '', 'I would like to request a customized bottled water order.', '',
      'CUSTOMER DETAILS', ...details.map(([label, value]) => `${label}: ${value}`), '',
      'ORDER REQUIREMENTS', ...requirements.map(([label, value]) => `${label}: ${value}`), '',
      'CUSTOM BRANDING', ...branding.map(([label, value]) => `${label}: ${value}`),
      ...(logoName ? ['', 'I understand the local logo file is not attached automatically. I will attach it manually in WhatsApp.'] : []),
      '', 'Please review my requirements and share your quotation, minimum order quantity, production details, and delivery options.', '', 'Thank you!', 'Crystal Drops Customer',
    ];
    return lines.join('\n');
  };
  const previewOrder = () => {
    if (!validateOrder(false)) { setFormStatus('Review the highlighted fields before opening your order preview.'); return; }
    setFormStatus('');
    setReviewOpen(true);
  };
  const sendOrder = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormStatus('');
    if (!validateOrder(true)) { setFormStatus('Please review the highlighted fields and consent notice. Nothing has been sent.'); setReviewOpen(false); return; }
    const url = whatsappUrl(orderMessage());
    const opened = window.open(url, '_blank');
    if (opened) opened.opener = null;
    else window.location.assign(url);
    setFormStatus('WhatsApp opened with a draft for you to review and send. Your inquiry is not delivered until you choose Send in WhatsApp.');
  };
  const navItems = [
    ['Home', '/'], ['Customize', '/customize'], ['Gallery', '/gallery'], ['How it works', '/how-it-works'],
    ['Industries', '/industries'], ['About', '/about'], ['FAQs', '/faq'],
  ];
  const activeConcepts = conceptFilter === 'All concepts' ? concepts : concepts.filter((concept) => concept.category === conceptFilter);
  const ordinaryMessage = (context: string) => `Hello Crystal Drops! I am interested in custom-labelled bottled drinking water for ${context}. Could you share more about the available options and how to discuss my requirements?`;
  const orderFormProps = {
    form, updateForm, errors: formErrors, consent, setConsent, status: formStatus, setStatus: setFormStatus,
    brandName, setBrand, palette, selectPalette, size, selectSize, cap, selectCap, logoUrl, logoName,
    logoMessage, handleLogo, reviewOpen, setReviewOpen, reviewHeadingRef, previewOrder,
    sendOrder, resetDesign,
  };

  return (
    <div className="site" onClick={handleSiteClick}>
      <header className="nav">
        <div className="container nav-inner">
          <a href="/" className="brand" aria-label="Crystal Drops home" data-testid="link-home">
            <span className="brand-mark"><Droplets size={19} strokeWidth={1.5} /></span>
            <span className="brand-name">CRYSTAL DROPS<small>KARACHI · CUSTOM LABELLED WATER</small></span>
          </a>
          <nav className={`nav-links ${navOpen ? 'open' : ''}`} aria-label="Main navigation">
            {navItems.map(([label, href]) => <a key={href} href={href} className={path === href ? 'active' : ''} aria-current={path === href ? 'page' : undefined} onClick={() => setNavOpen(false)} data-testid={`link-nav-${href === '/' ? 'home' : href.slice(1)}`}>{label}</a>)}
            <a href="/contact" className="nav-cta" aria-current={path === '/contact' ? 'page' : undefined} onClick={() => setNavOpen(false)} data-testid="link-nav-contact">Request a quote <ArrowRight size={13} /></a>
          </nav>
          <button className="menu-toggle" type="button" aria-label={navOpen ? 'Close navigation menu' : 'Open navigation menu'} aria-expanded={navOpen} onClick={() => setNavOpen((value) => !value)} data-testid="button-menu-toggle">{navOpen ? <X size={20} /> : <Menu size={20} />}</button>
        </div>
      </header>

      <main id="main-content">
        <Switch>
          <Route path="/"><HomePage ordinaryMessage={ordinaryMessage} /></Route>
          <Route path="/customize"><CustomizePage {...orderFormProps} /></Route>
          <Route path="/gallery"><GalleryPage concepts={activeConcepts} filter={conceptFilter} setFilter={setConceptFilter} openConcept={openConcept} /></Route>
          <Route path="/how-it-works"><ProcessPage ordinaryMessage={ordinaryMessage} /></Route>
          <Route path="/industries"><IndustriesPage ordinaryMessage={ordinaryMessage} /></Route>
          <Route path="/about"><AboutPage ordinaryMessage={ordinaryMessage} /></Route>
          <Route path="/contact"><ContactPage {...orderFormProps} ordinaryMessage={ordinaryMessage} /></Route>
          <Route path="/faq"><FaqPage openFaq={openFaq} setOpenFaq={setOpenFaq} /></Route>
          <Route component={NotFound} />
        </Switch>
      </main>

      <Footer />
      <WhatsAppLink message={ordinaryMessage('my business')} className="floating-wa" testId="link-floating-whatsapp" label="Open a WhatsApp inquiry with Crystal Drops"><MessageCircle size={19} /><span>WhatsApp</span></WhatsAppLink>

      {loading && <div className="route-loader" role="status" aria-live="polite" aria-label="Loading Crystal Drops page" data-testid="status-route-loader">
        <div className="loader-content"><div className="loader-ripple"><span /><Droplets size={26} strokeWidth={1.4} /></div><strong>CRYSTAL DROPS</strong><span className="loader-subtitle">PURE DRINKING WATER</span><div className="loader-track"><span /></div></div>
      </div>}

      {activeConcept && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) closeConcept(); }} data-testid="modal-concept-backdrop">
        <section className="modal" role="dialog" aria-modal="true" aria-labelledby="concept-modal-title" ref={dialogRef} tabIndex={-1} data-testid="modal-concept">
          <button className="modal-close" type="button" onClick={closeConcept} aria-label="Close concept preview" data-testid="button-close-concept"><X size={19} /></button>
          <div className="modal-art"><Bottle size="500 ml" palette={activeConcept.palette} name={activeConcept.name} cap="#071827" /></div>
          <div className="modal-info"><span className="eyebrow">Fictional sample · {activeConcept.category}</span><h2 id="concept-modal-title">{activeConcept.name}</h2><p>{activeConcept.description}</p><p><b>{activeConcept.tagline}</b></p><p className="sample-note">Illustrative concept only. Not a real customer or completed order.</p>
            <div className="modal-actions"><a href="/customize" className="button button-dark" onClick={() => { selectPalette(activeConcept.palette); setBrand(activeConcept.name); setActiveConcept(null); }}>Customize this direction <ArrowRight size={14} /></a><WhatsAppLink message={ordinaryMessage(`a ${activeConcept.category.toLowerCase()} label concept like ${activeConcept.name}`)} className="button button-gold" testId={`button-whatsapp-concept-${activeConcept.id}`} label={`Ask about the fictional ${activeConcept.name} concept on WhatsApp`}>Ask on WhatsApp <MessageCircle size={15} /></WhatsAppLink></div>
          </div>
        </section>
      </div>}
    </div>
  );
}

function PageHero({ eyebrow, title, description, children }: { eyebrow: string; title: ReactNode; description: string; children?: ReactNode }) {
  return <section className="page-hero"><div className="container page-hero-content"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{description}</p>{children}</div><div className="page-hero-ornament" aria-hidden="true"><span /></div></section>;
}

function HomePage({ ordinaryMessage }: { ordinaryMessage: (context: string) => string }) {
  return <>
    <section className="hero" id="home" aria-labelledby="hero-title">
      <div className="container hero-grid">
        <div className="hero-copy reveal"><div className="hero-kicker eyebrow">A detail that carries your identity</div><h1 className="display" id="hero-title">YOUR BRAND.{' '}<span>YOUR BOTTLE.</span></h1><h2 className="hero-subtitle">Premium Custom-Labelled Drinking Water</h2><p>Turn every bottle into a powerful expression of your brand. We create customized bottled water featuring your logo, your identity, and your style.</p>
          <div className="hero-actions"><a className="button button-gold" href="/customize" data-testid="button-customize-hero">Customize your bottle <ArrowRight size={15} /></a><a className="button button-outline" href="/gallery" data-testid="button-explore-gallery">Explore the concepts</a></div>
          <div className="hero-actions hero-whatsapp"><WhatsAppLink message={ordinaryMessage('my restaurant, hotel, company or event')} className="button button-outline" testId="button-whatsapp-home" label="Ask Crystal Drops about custom-labelled water on WhatsApp"><MessageCircle size={15} /> Ask on WhatsApp</WhatsAppLink></div>
          <div className="hero-caption"><span />Karachi-based · Made to reflect your brand</div>
        </div>
        <div className="hero-product" aria-label="Illustrative custom-labelled bottle preview"><div className="hero-halo" aria-hidden="true" /><Bottle size="500 ml" palette="black" name="Your Brand" cap="#071827" className="hero-bottle-wrap" loading="eager" /><div className="product-caption">Your identity, on the label</div></div>
      </div>
      <a className="scroll-mark" href="#home-intro" aria-label="Scroll to discover">Scroll to discover</a>
    </section>
    <section className="intro-strip" id="home-intro"><div className="container intro-grid"><div className="intro-mark"><span className="eyebrow">A different kind of bottle</span><strong>The bottle carries your brand.<br />Not ours.</strong></div><p className="intro-text">Crystal Drops creates custom-labelled bottled drinking water for businesses and occasions. <b>Your logo, name and visual identity take the lead</b>—so the bottle feels considered within your own setting, from a restaurant table to a company gathering.</p></div></section>
    <section className="section home-pathways"><div className="container"><div className="section-head center"><span className="eyebrow">The brand is yours</span><h2>One simple idea.<br />Many ways to make it yours.</h2><p>Explore a label direction, see fictional sample concepts, or learn what to expect when you enquire.</p></div><div className="pathway-grid">
      <a className="pathway-card pathway-customize" href="/customize"><span className="eyebrow">01 · Start with your identity</span><h3>Preview your bottle.</h3><p>Test a size, cap and label palette with your own name and logo preview.</p><span className="pathway-action">Open the customizer <ArrowRight size={14} /></span></a>
      <a className="pathway-card pathway-gallery" href="/gallery"><span className="eyebrow">02 · Find a direction</span><h3>Explore the concepts.</h3><p>Fictional sample brands show how labels can take on a very different character.</p><span className="pathway-action">View the gallery <ArrowRight size={14} /></span></a>
      <a className="pathway-card pathway-process" href="/how-it-works"><span className="eyebrow">03 · Know what comes next</span><h3>Understand the process.</h3><p>Start with your brand, review a concept and confirm practical details before production.</p><span className="pathway-action">How it works <ArrowRight size={14} /></span></a>
    </div></div></section>
    <section className="section home-industries"><div className="container home-industries-layout"><div className="section-head"><span className="eyebrow">For your setting</span><h2>Let the bottle<br />belong to your brand.</h2><p>Restaurants, cafes, hotels, company gatherings and special events each have their own visual language. Start with yours.</p><a href="/industries" className="text-link">Find your industry <ArrowRight size={14} /></a></div><div className="home-industry-list"><span><Utensils size={16} /> Restaurants & cafés</span><span><Hotel size={16} /> Hotels & hospitality</span><span><Droplets size={16} /> Corporate & meetings</span><span><Sparkles size={16} /> Weddings & events</span></div></div></section>
    <BenefitsSection />
    <section className="section home-process"><div className="container"><div className="section-head center"><span className="eyebrow">A clear place to begin</span><h2>From your idea<br />to a bottle concept.</h2><p>Order details, timing and delivery arrangements are confirmed with you before an order is agreed.</p></div><ProcessSteps /><div className="center-action"><a href="/how-it-works" className="button button-gold">See the full process <ArrowRight size={14} /></a></div></div></section>
    <section className="home-cta"><div className="container home-cta-inner"><div><span className="eyebrow">Your brand, your bottle</span><h2>Ready to see your name on it?</h2><p>Build an illustrative preview and prepare your inquiry on WhatsApp.</p></div><div className="hero-actions"><a href="/customize" className="button button-gold">Customize your bottle <ArrowRight size={14} /></a><WhatsAppLink message={ordinaryMessage('a business or event')} className="button button-outline" testId="button-whatsapp-home-cta" label="Ask a question on WhatsApp">Ask on WhatsApp <MessageCircle size={14} /></WhatsAppLink></div></div></section>
  </>;
}

function BenefitsSection() {
  const benefits = [
    ['01', 'Custom label direction', 'Start with your own business name, logo and preferred design direction.'],
    ['02', 'Brand-color coordination', 'Explore label palettes informed by the identity you want to show.'],
    ['03', 'Bottle-size options', 'Preview 500 ml and 1.5 L; actual availability needs to be confirmed.'],
    ['04', 'Review before production', 'Discuss and approve the proposed design and specifications before production.'],
  ];
  return <section className="section benefits"><div className="container benefit-layout"><div className="benefits-intro"><span className="eyebrow">Your identity, considered</span><h2>Made personal<br />to your brand.</h2><p>A way to explore custom-labelled water with your brand in focus. Practical details can be confirmed around your requirements.</p></div><div className="benefit-list">{benefits.map(([number, title, description]) => <article className="benefit-item" key={number}><span>{number}</span><h3>{title}</h3><p>{description}</p></article>)}</div></div></section>;
}

function ProcessSteps() {
  const steps = [['01', 'Share your brand', 'Send your logo, brand name and preferred design direction.'], ['02', 'Design your label', 'Explore a customized bottle-label concept aligned with your identity.'], ['03', 'Approve the design', 'Review the proposed design and confirm specifications before production.'], ['04', 'Agree next steps', 'Production and delivery arrangements are discussed and confirmed.']];
  return <div className="process-grid">{steps.map(([number, title, detail]) => <article className="process-step" key={number}><span className="step-number">{number}</span><h3>{title}</h3><p>{detail}</p></article>)}</div>;
}

type OrderFormProps = {
  form: OrderForm; updateForm: (key: keyof OrderForm, value: string) => void; errors: Record<string, string>;
  consent: boolean; setConsent: (value: boolean) => void; status: string; setStatus: (value: string) => void;
  brandName: string; setBrand: (value: string) => void; palette: PaletteKey; selectPalette: (key: PaletteKey) => void;
  size: string; selectSize: (value: string) => void; cap: string; selectCap: (value: string) => void;
  logoUrl: string | null; logoName: string; logoMessage: string; handleLogo: (event: ChangeEvent<HTMLInputElement>) => void;
  reviewOpen: boolean; setReviewOpen: (value: boolean) => void; reviewHeadingRef: RefObject<HTMLHeadingElement | null>;
  previewOrder: () => void; sendOrder: (event: FormEvent<HTMLFormElement>) => void;
  resetDesign: () => void;
};

function OrderForm({ props, title = 'Bottle preview and inquiry', compact = false }: { props: OrderFormProps; title?: string; compact?: boolean }) {
  const { form, updateForm, errors, consent, setConsent, status, setStatus, brandName, setBrand, palette, selectPalette, size, selectSize, cap, selectCap, logoUrl, logoName, logoMessage, handleLogo, reviewOpen, setReviewOpen, reviewHeadingRef, previewOrder, sendOrder, resetDesign } = props;
  const updateBrand = (value: string) => setBrand(value);
  const label = (key: keyof OrderForm | 'consent') => errors[key] ? <span className="field-error" id={`error-${key}`}>{errors[key]}</span> : null;
  const fieldProps = (key: keyof OrderForm) => ({ 'aria-invalid': Boolean(errors[key]), 'aria-describedby': errors[key] ? `error-${key}` : undefined });
  const updateColorInput = (value: string) => {
    updateForm('labelColors', value);
    const matching = palettes.find((item) => item.name.toLowerCase() === value.toLowerCase());
    if (matching) selectPalette(matching.key);
  };
  const changeSize = (value: string) => selectSize(value);
  const changeCap = (value: string) => {
    const option = capOptions.find((item) => item.label === value);
    updateForm('capPreference', value);
    if (option) selectCap(option.value);
  };
  return <div className={`order-experience ${compact ? 'compact' : ''}`} id="order-details">
    <div className="order-intro"><span className="eyebrow">{title}</span><p>Preview choices are illustrative. Availability, pricing, quantity and arrangements need to be confirmed directly.</p></div>
    {!reviewOpen ? <div className="order-workspace">
      <div className="order-live-preview">
        <div className="order-preview-art"><Bottle size={size} palette={palette} name={brandName || form.brandName || 'Your Brand'} cap={cap} logo={logoUrl} labelStyle={form.labelStyle} /></div>
        <div className="order-preview-caption"><span className="eyebrow">Live label preview</span><span>{size} · {paletteFor(palette).name}</span></div>
        <div className="preview-controls">
          <div><span className="control-label">Bottle size</span><div className="size-options">{['500 ml', '1.5 L'].map((value) => <button key={value} type="button" className="choice" aria-pressed={size === value} onClick={() => changeSize(value)} data-testid={`button-custom-size-${value.replace(/ /g, '-')}`}>{value}</button>)}</div></div>
          <div><span className="control-label">Label palette</span><div className="palette-options">{palettes.map((item) => <button key={item.key} type="button" className="palette-choice" aria-label={item.name} aria-pressed={palette === item.key} title={item.name} onClick={() => selectPalette(item.key)} data-testid={`button-custom-palette-${item.key}`}><span style={{ background: item.swatch }} /></button>)}</div></div>
          <div><span className="control-label">Cap color</span><div className="cap-options">{capOptions.map((item) => <button key={item.value} type="button" className="cap-choice" aria-label={`${item.label} cap`} aria-pressed={cap === item.value} onClick={() => selectCap(item.value)} data-testid={`button-custom-cap-${item.value.slice(1).toLowerCase()}`}><span style={{ background: item.value, border: item.value === '#FFFFFF' ? '1px solid #9db5c2' : undefined }} /></button>)}</div></div>
          <label className="field"><span className="control-label">Client brand name on label</span><input className="control-input" value={brandName === 'Your Brand' ? form.brandName : brandName} maxLength={28} onChange={(event) => updateBrand(event.target.value)} data-testid="input-custom-brand-name" />{label('brandName')}</label>
          <label className="upload-label"><Upload size={15} />{logoName || 'Add a local logo preview'}<input type="file" accept=".png,.jpg,.jpeg,.svg,image/png,image/jpg,image/jpeg,image/svg+xml" onChange={handleLogo} data-testid="input-custom-logo" /></label>
          <div className="file-hint" role="status" data-testid="status-logo-upload">{logoMessage || 'PNG, JPG, JPEG or SVG · max 3 MB · kept on this device. Attach manually in WhatsApp after it opens.'}</div>
          <div className="preview-actions"><button type="button" className="button button-dark" onClick={previewOrder} data-testid="button-preview-my-bottle">Preview My Bottle <ArrowRight size={14} /></button><button type="button" className="reset-button" onClick={resetDesign} data-testid="button-reset-design"><RotateCcw size={15} /> Reset Design</button></div>
        </div>
      </div>
      <form className="quote-form order-form" onSubmit={(event) => { event.preventDefault(); previewOrder(); }} noValidate data-testid="form-order-inquiry">
        <h2 className="form-heading">Your order details</h2>
        <div className="form-grid">
          <div className="field"><label htmlFor="order-business">Business / customer name *</label><input id="order-business" autoComplete="organization" value={form.businessName} onChange={(e) => updateForm('businessName', e.target.value)} {...fieldProps('businessName')} data-testid="input-order-business" />{label('businessName')}</div>
          <div className="field"><label htmlFor="order-contact">Contact person's name *</label><input id="order-contact" autoComplete="name" value={form.contactName} onChange={(e) => updateForm('contactName', e.target.value)} {...fieldProps('contactName')} data-testid="input-order-contact" />{label('contactName')}</div>
          <div className="field"><label htmlFor="order-phone">Phone number *</label><input id="order-phone" type="tel" autoComplete="tel" value={form.phone} onChange={(e) => updateForm('phone', e.target.value)} {...fieldProps('phone')} data-testid="input-order-phone" />{label('phone')}</div>
          <div className="field"><label htmlFor="order-email">Email address <span>(optional)</span></label><input id="order-email" type="email" autoComplete="email" value={form.email} onChange={(e) => updateForm('email', e.target.value)} {...fieldProps('email')} data-testid="input-order-email" />{label('email')}</div>
          <div className="field"><label htmlFor="order-size">Bottle size *</label><select id="order-size" value={form.size} onChange={(e) => changeSize(e.target.value)} {...fieldProps('size')} data-testid="select-order-size"><option value="">Select size</option><option>500 ml</option><option>1.5 L</option></select>{label('size')}</div>
          <div className="field"><label htmlFor="order-quantity">Estimated quantity *</label><input id="order-quantity" inputMode="numeric" value={form.quantity} onChange={(e) => updateForm('quantity', e.target.value)} placeholder="Enter an estimate" {...fieldProps('quantity')} data-testid="input-order-quantity" />{label('quantity')}</div>
          <div className="field"><label htmlFor="order-category">Business category *</label><select id="order-category" value={form.category} onChange={(e) => updateForm('category', e.target.value)} {...fieldProps('category')} data-testid="select-order-category"><option value="">Select category</option>{['Restaurant', 'Cafe', 'Hotel / hospitality', 'Corporate', 'Wedding / event', 'Brand / promotion', 'Other'].map((item) => <option key={item}>{item}</option>)}</select>{label('category')}</div>
          <div className="field"><label htmlFor="order-area">Delivery city or area *</label><input id="order-area" autoComplete="address-level2" value={form.deliveryArea} onChange={(e) => updateForm('deliveryArea', e.target.value)} placeholder="City / area" {...fieldProps('deliveryArea')} data-testid="input-order-delivery-area" />{label('deliveryArea')}</div>
          <div className="field"><label htmlFor="order-label-brand">Client brand name *</label><input id="order-label-brand" value={form.brandName || (brandName !== 'Your Brand' ? brandName : '')} onChange={(e) => updateBrand(e.target.value)} {...fieldProps('brandName')} data-testid="input-order-brand-name" />{label('brandName')}</div>
          <div className="field"><label htmlFor="order-colors">Label colors *</label><select id="order-colors" value={form.labelColors} onChange={(e) => updateColorInput(e.target.value)} {...fieldProps('labelColors')} data-testid="select-order-colors">{palettes.map((item) => <option key={item.key}>{item.name}</option>)}<option>Other / describe in instructions</option></select>{label('labelColors')}</div>
          <div className="field"><label htmlFor="order-style">Preferred label style *</label><select id="order-style" value={form.labelStyle} onChange={(e) => updateForm('labelStyle', e.target.value)} {...fieldProps('labelStyle')} data-testid="select-order-style"><option value="">Choose a direction</option><option>Minimal</option><option>Elegant</option><option>Bold</option><option>Classic</option><option>Modern</option><option>Other / discuss</option></select>{label('labelStyle')}</div>
          <div className="field"><label htmlFor="order-cap">Cap preference *</label><select id="order-cap" value={form.capPreference} onChange={(e) => changeCap(e.target.value)} {...fieldProps('capPreference')} data-testid="select-order-cap">{capOptions.map((item) => <option key={item.value}>{item.label}</option>)}<option>Other / subject to availability</option></select>{label('capPreference')}</div>
          <div className="field full"><label htmlFor="order-instructions">Additional design instructions <span>(optional)</span></label><textarea id="order-instructions" value={form.instructions} onChange={(e) => updateForm('instructions', e.target.value)} placeholder="Share your preferred feel, logo placement or event details." data-testid="textarea-order-instructions" /></div>
        </div>
        <label className="consent"><input type="checkbox" checked={consent} onChange={(e) => { setConsent(e.target.checked); setStatus(''); }} aria-invalid={!!errors.consent && !consent} data-testid="checkbox-order-consent" /><span>I agree to share the details I entered with Crystal Drops by opening WhatsApp. The page does not transmit or store my information, and I can review the draft before sending.</span></label>
        {!consent && label('consent')}
        <div className="form-actions"><button type="submit" className="button button-dark" data-testid="button-preview-details">Review order details <ArrowRight size={14} /></button></div>
        {status && <div className="form-status" role="status" aria-live="polite" data-testid="status-order-form">{status}</div>}
        <p className="form-footnote">The WhatsApp inquiry is a draft. An order is not placed or confirmed until Crystal Drops reviews and confirms it.</p>
      </form>
    </div> : <section className="order-review" aria-labelledby="review-heading" data-testid="order-review">
      <div className="review-top"><div><span className="eyebrow">Review before opening WhatsApp</span><h2 ref={reviewHeadingRef} tabIndex={-1} id="review-heading">Your bottle direction.</h2><p>Check the bottle and order details below. Nothing is sent until you choose Send in WhatsApp.</p></div><button type="button" className="button button-outline-dark" onClick={() => setReviewOpen(false)} data-testid="button-edit-my-details">Edit My Details <ArrowRight size={14} /></button></div>
      <div className="review-grid"><div className="review-bottle"><Bottle size={form.size} palette={palette} name={form.brandName || brandName} cap={cap} logo={logoUrl} labelStyle={form.labelStyle} /></div><div className="review-details">
        <h3>Order summary</h3><dl>{[
          ['Business', form.businessName], ['Contact', form.contactName], ['Phone', form.phone], ...(form.email ? [['Email', form.email]] : []),
          ['Size', form.size], ['Quantity', form.quantity], ['Category', form.category], ['Delivery area', form.deliveryArea],
          ['Client brand', form.brandName || brandName], ['Label colors', form.labelColors], ['Label style', form.labelStyle], ['Cap preference', form.capPreference],
          ...(logoName ? [['Logo file', logoName]] : []), ...(form.instructions.trim() ? [['Instructions', form.instructions]] : []),
        ].map(([labelText, value]) => <div className="review-line" key={labelText}><dt>{labelText}</dt><dd>{value}</dd></div>)}</dl>
        {logoName && <p className="review-file-note" data-testid="text-logo-attachment-note">Your logo is previewed locally only. After WhatsApp opens, attach <b>{logoName}</b> manually to the chat.</p>}
        <label className="consent review-consent"><input type="checkbox" checked={consent} onChange={(e) => { setConsent(e.target.checked); setStatus(''); }} aria-invalid={!!errors.consent && !consent} data-testid="checkbox-review-consent" /><span>I agree to share these details in a WhatsApp inquiry draft. I will review the message before sending.</span></label>
        {!consent && label('consent')}
        <form onSubmit={sendOrder} data-testid="form-send-order"><div className="form-actions"><button className="button button-gold" type="submit" data-testid="button-send-order-whatsapp">Send Order Inquiry on WhatsApp <MessageCircle size={15} /></button><button type="button" className="reset-button" onClick={resetDesign} data-testid="button-reset-design-review"><RotateCcw size={15} /> Reset Design</button></div></form>
        {status && <div className="form-status" role="status" aria-live="polite" data-testid="status-order-form">{status}</div>}
        <p className="form-footnote">WhatsApp opening does not mean that your inquiry was delivered or that an order was placed. Review the recipient, draft and logo attachment, then send it yourself.</p>
      </div></div>
    </section>}
  </div>;
}

function CustomizePage(props: OrderFormProps) {
  const ordinary = 'Hello Crystal Drops! I am interested in exploring a custom-labelled water bottle for my business. Could you share how the design and order discussion works?';
  return <><PageHero eyebrow="Interactive bottle studio" title={<>Make your bottle<br />your own.</>} description="Try a label direction, add your brand name and prepare a detailed inquiry. The preview is illustrative; final design and availability must be confirmed." /><section className="section custom-page-section"><div className="container"><div className="section-head"><span className="eyebrow">Your bottle concept</span><h2>A first look.<br />A starting point.</h2><p>Change the size, palette, cap and client brand name. Logo artwork stays in this browser and must be attached manually in WhatsApp.</p></div><OrderForm props={props} title="Customize your bottle" /><div className="custom-wa-cta"><span><b>Want to ask a question first?</b><small>Open a WhatsApp chat with a general inquiry. No order details are sent by this link.</small></span><WhatsAppLink message={ordinary} className="button button-gold" testId="button-whatsapp-customizer" label="Ask Crystal Drops about custom bottle options on WhatsApp">Ask on WhatsApp <MessageCircle size={15} /></WhatsAppLink></div></div></section></>;
}

function GalleryPage({ concepts: items, filter, setFilter, openConcept }: { concepts: Concept[]; filter: string; setFilter: (value: string) => void; openConcept: (concept: Concept, event: MouseEvent<HTMLButtonElement>) => void }) {
  return <><PageHero eyebrow="A library of directions" title={<>Different brands.<br />Different bottles.</>} description="Explore fictional sample concepts that show how a label can shift with the character of a business. These are inspirations, not client work." /><section className="section gallery" id="gallery"><div className="container"><div className="gallery-toolbar"><div className="filters" role="group" aria-label="Filter fictional concepts by industry">{categories.map((category) => <button key={category} type="button" className="filter" aria-pressed={filter === category} onClick={() => setFilter(category)} data-testid={`button-filter-${category.toLowerCase().replace(/ /g, '-')}`}>{category}</button>)}</div><span className="sample-note" data-testid="text-concept-count">{items.length} fictional concepts</span></div><div className="gallery-grid" data-testid="gallery-grid">{items.map((concept) => <button type="button" className="concept-card" key={concept.id} onClick={(event) => openConcept(concept, event)} aria-label={`Open ${concept.name}, fictional ${concept.category.toLowerCase()} concept`} data-testid={`card-concept-${concept.id}`}><span className="concept-label-tag">Fictional sample concept</span><Bottle size="500 ml" palette={concept.palette} name={concept.name} cap="#071827" /><span className="concept-meta"><span><strong>{concept.name}</strong><small>{concept.category} · {concept.tagline}</small></span><span className="concept-arrow"><ArrowRight size={18} /></span></span></button>)}</div><p className="gallery-foot">Every brand shown is fictional and created for illustration. No customer relationship or completed commercial order is implied.</p><div className="center-action"><a className="button button-dark" href="/customize">Create a direction of your own <ArrowRight size={14} /></a></div></div></section></>;
}

function ProcessPage({ ordinaryMessage }: { ordinaryMessage: (context: string) => string }) {
  return <><PageHero eyebrow="A clear place to begin" title={<>A thoughtful process.<br />From first idea.</>} description="Start with your brand identity. Review a design direction and confirm specifications, availability and terms before any production is agreed." /><section className="section process" id="process"><div className="container"><div className="process-grid process-grid-page">
    {[
      ['01', 'Share your brand', 'Send your logo, business name and preferred design direction. Share your setting, estimated quantity and the bottle size you have in mind.'],
      ['02', 'Design your label', 'A customized bottle-label concept can be prepared around your brand identity and preferences. Sample concepts on this site are illustrative only.'],
      ['03', 'Review and approve', 'Review the proposed design and confirm specifications before production. Ask questions about pricing, minimum quantities and availability.'],
      ['04', 'Agree next steps', 'Once your order details are confirmed, production and delivery arrangements can be discussed according to the agreed terms.'],
    ].map(([number, title, body]) => <article className="process-step" key={number}><span className="step-number">{number}</span><h2>{title}</h2><p>{body}</p></article>)}
  </div><div className="process-reminder"><MapPin size={18} /><p>MOQ, pricing, delivery area and turnaround time have not been specified here. Confirm each detail directly before placing an order.</p></div></div></section><section className="section process-cta"><div className="container center-action"><a className="button button-gold" href="/customize">Start a bottle preview <ArrowRight size={14} /></a><WhatsAppLink message={ordinaryMessage('a custom-labelled water order')} className="button button-outline-dark" testId="button-whatsapp-process" label="Ask about the custom-label process on WhatsApp">Ask about the process <MessageCircle size={15} /></WhatsAppLink></div></section></>;
}

function IndustriesPage({ ordinaryMessage }: { ordinaryMessage: (context: string) => string }) {
  const industries = [
    ['Restaurants', 'Make your brand part of the dining experience.', 'A label direction can draw from your menu, room and the way you welcome guests.'],
    ['Hotels & hospitality', 'Bring your visual identity to every guest interaction.', 'Explore a bottle presentation that sits naturally within your hospitality environment.'],
    ['Cafes', 'Give your café identity a place on the table.', 'Try a quieter, more playful or more distinctive label direction around your brand.'],
    ['Corporate companies', 'Create a consistent brand experience at meetings and events.', 'Use your company identity as the starting point for hosted meetings and gatherings.'],
    ['Weddings & events', 'Add a personal detail to a special occasion.', 'Explore customized label concepts for your celebration or event setting.'],
    ['Brands & promotions', 'Put your brand identity into the hands of your audience.', 'Discuss a label direction suited to a brand activation or promotional requirement.'],
  ];
  return <><PageHero eyebrow="For the places people gather" title={<>For your industry.<br />In your identity.</>} description="Custom-labelled bottle concepts for hospitality, business gatherings and special occasions. Requirements and availability are discussed individually." /><section className="section industries-page"><div className="container"><div className="industry-cards">{industries.map(([title, summary, copy]) => <article className="industry-detail-card" key={title}><span className="eyebrow">A direction for</span><h2>{title}</h2><h3>{summary}</h3><p>{copy}</p><WhatsAppLink message={ordinaryMessage(`${title.toLowerCase()}`)} className="text-link" testId={`button-whatsapp-industry-${title.toLowerCase().replace(/[^a-z]+/g, '-')}`} label={`Ask Crystal Drops about custom-labelled water for ${title}`}>Ask about {title.toLowerCase()} <ArrowRight size={14} /></WhatsAppLink></article>)}</div><p className="gallery-foot">No current customer examples are presented. Brand concepts shown elsewhere are fictional samples.</p></div></section></>;
}

function AboutPage({ ordinaryMessage }: { ordinaryMessage: (context: string) => string }) {
  return <><PageHero eyebrow="About Crystal Drops" title={<>Your brand is the<br />visual focus.</>} description="Crystal Drops is a Karachi-based custom-labelled drinking-water business for restaurants, hotels, cafes, companies and event organizers." /><section className="section about" id="about"><div className="container about-layout"><div className="about-art"><Bottle size="500 ml" palette="blue" name="Your Brand" cap="#D6B15E" /></div><div className="about-copy"><span className="eyebrow">The idea is simple</span><h2>The bottle carries<br />your identity.</h2><p>Crystal Drops supplies bottled drinking water with customized labels featuring each client's brand name, logo and preferred visual theme. The label begins with your identity—not with the service provider's brand.</p><p>The site is designed to help you explore that idea, try a visual direction and share the requirements you'd like to discuss. A preview is illustrative and does not represent a finished product or verified customer order.</p><p className="about-note">The particulars matter. Confirm available sizes, quantity, pricing, quality specifications and delivery arrangements directly before you proceed.</p><a href="/customize" className="button button-dark">Explore a bottle preview <ArrowRight size={14} /></a><div className="about-whatsapp"><WhatsAppLink message={ordinaryMessage('custom-labelled bottled water from Crystal Drops')} className="text-link" testId="button-whatsapp-about" label="Ask Crystal Drops a question on WhatsApp">Ask us on WhatsApp <MessageCircle size={14} /></WhatsAppLink></div></div></div></section></>;
}

function FaqPage({ openFaq, setOpenFaq }: { openFaq: number | null; setOpenFaq: (value: number | null) => void }) {
  const faqs = [
    ['How does custom bottle labeling work?', 'Share your business name, logo and design preferences in an inquiry. A label direction and specifications can be discussed with you; final production details would need to be agreed before an order is confirmed.'],
    ['Can I use my own company logo?', 'Yes. Upload a local logo preview on the customizer. The file stays in your browser and is not transmitted. If you open WhatsApp, you will need to attach the logo manually in that chat.'],
    ['Can the label match my brand colors?', 'The label concept can be guided by your preferred colors and visual identity. The palettes on this site are illustrative examples, not a production color proof.'],
    ['Which bottle sizes are available?', 'This site previews 500 ml and 1.5 L sizes. Actual availability should be confirmed directly with Crystal Drops.'],
    ['What is the minimum order quantity?', 'A minimum order quantity has not been provided on this site. Include an estimate in your inquiry so it can be discussed.'],
    ['How is pricing determined?', 'Pricing information has not been provided. Discuss your size, estimated quantity and customization requirements for a quotation.'],
    ['Can I request a sample design?', 'Yes. Use the customizer to create an illustrative direction, then review the selections and open a WhatsApp inquiry draft. It is not sent until you choose Send in WhatsApp.'],
    ['What are the delivery arrangements?', 'Delivery coverage, area availability and timing have not been confirmed here. Discuss and agree arrangements directly before ordering.'],
    ['Does opening WhatsApp place my order?', 'No. WhatsApp opens a draft message for you to review and send. It is an inquiry only, and the order is not placed or confirmed until Crystal Drops reviews and confirms it.'],
  ];
  return <><PageHero eyebrow="Good to know" title={<>Clear answers.<br />No guesswork.</>} description="Details not confirmed here are stated plainly. Discuss your requirements directly before an order is agreed." /><section className="section faq" id="faq"><div className="container faq-layout"><div className="faq-intro"><span className="eyebrow">Frequently asked questions</span><h2>Practical details,<br />answered clearly.</h2><p>Have a question that is not covered? Contact Crystal Drops through WhatsApp.</p><WhatsAppLink message="Hello Crystal Drops! I have a question about custom-labelled bottled water. Could you help me with some details?" className="button button-dark" testId="button-whatsapp-faq" label="Ask a Crystal Drops question on WhatsApp">Ask a question <MessageCircle size={15} /></WhatsAppLink></div><div className="faq-list">{faqs.map(([question, answer], index) => <div className="faq-item" key={question}><button type="button" className="faq-question" aria-expanded={openFaq === index} aria-controls={`faq-answer-${index}`} onClick={() => setOpenFaq(openFaq === index ? null : index)} data-testid={`button-faq-${index + 1}`}><span>{question}</span><span aria-hidden="true">+</span></button>{openFaq === index && <div className="faq-answer" id={`faq-answer-${index}`} data-testid={`text-faq-answer-${index + 1}`}>{answer}</div>}</div>)}</div></div></section></>;
}

function ContactPage({ ...props }: OrderFormProps & { ordinaryMessage: (context: string) => string }) {
  const { ordinaryMessage, ...formProps } = props;
  return <><PageHero eyebrow="Contact & order inquiry" title={<>Tell us what<br />you have in mind.</>} description="Complete an inquiry draft with your requirements and open the official Crystal Drops WhatsApp chat. Review and send it yourself." /><section className="section contact-page"><div className="container contact-intro"><div className="contact-callout"><span className="eyebrow">Direct contact</span><h2>Prefer to start with a question?</h2><p>Use WhatsApp to ask about custom-labelled drinking water. No order information is shared through this general link.</p><WhatsAppLink message={ordinaryMessage('custom-labelled drinking water')} className="button button-gold" testId="button-whatsapp-contact" label="Contact Crystal Drops on WhatsApp">Continue to WhatsApp <MessageCircle size={15} /></WhatsAppLink></div><div className="contact-number"><span className="eyebrow">Official WhatsApp</span><strong>+92 321 248 6102</strong><span>Orders and arrangements are subject to direct confirmation.</span></div></div><div className="container"><OrderForm props={formProps} title="Prepare an order inquiry" compact /></div></section></>;
}

function NotFound() {
  return <section className="section not-found"><div className="container"><span className="eyebrow">Page not found</span><h1>That page isn't<br />on the label.</h1><p>The link may have moved. Head back to Crystal Drops and explore your options.</p><a href="/" className="button button-dark">Back to home <ArrowRight size={14} /></a></div></section>;
}

function Footer() {
  return <footer className="footer"><div className="container"><div className="footer-top"><div><a href="/" className="brand"><span className="brand-mark"><Droplets size={19} /></span><span className="brand-name">CRYSTAL DROPS<small>KARACHI · CUSTOM LABELLED WATER</small></span></a><p className="footer-copy">A Karachi-based custom-labelled drinking-water business. Your brand is the visual focus, bottle by bottle.</p><span className="footer-contact">Official WhatsApp: +92 321 248 6102</span></div><nav className="footer-nav" aria-label="Footer navigation"><div><strong>Explore</strong><a href="/customize">Customize your bottle</a><a href="/gallery">Design gallery</a><a href="/industries">Industries</a></div><div><strong>Discover</strong><a href="/how-it-works">How it works</a><a href="/about">About Crystal Drops</a><a href="/faq">FAQs</a></div><div><strong>Start a conversation</strong><a href="/contact">Order inquiry</a><WhatsAppLink message="Hello Crystal Drops! I would like to ask about custom-labelled drinking water." className="footer-wa-link" testId="link-footer-whatsapp" label="Open Crystal Drops WhatsApp">WhatsApp Crystal Drops</WhatsAppLink></div></nav></div><div className="footer-bottom"><span>© {new Date().getFullYear()} Crystal Drops</span><span>WhatsApp opens an inquiry draft; your order is not confirmed until reviewed.</span><a href="/" style={{ color: 'inherit', textDecoration: 'none' }}>Back to home ↑</a></div></div></footer>;
}

export default App;
